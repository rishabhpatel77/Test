import React from "react";

const A = "/assets/";

function SectionTitle({ children }) {
  return (
    <h2 className="section-title">
      <span className="title-bubble" />
      <span>{children}</span>
    </h2>
  );
}

function App() {
  return (
    <main className="page-shell">
      <article className="resume">
        <header className="header">
          <img className="college-logo left-logo" src={`${A}img0.png`} alt="MITS Gwalior logo" />

          <div className="institution">
            <div className="hindi">माधव प्रौद्योगिकी एवं विज्ञान संस्थान, ग्वालियर (म.प्र.), भारत</div>
            <div className="english">Madhav Institute of Technology &amp; Science, Gwalior (M.P.), INDIA</div>
            <div className="deemed">Deemed University</div>
            <div className="distinct">
              (Declared under Distinct Category by Ministry of Education,<br />
              Government of India)
            </div>
            <div className="naac">NAAC ACCREDITED WITH A++ GRADE</div>
            <div className="resume-label">RESUME</div>
          </div>

          <img className="college-logo right-logo" src={`${A}img1.png`} alt="MITS emblem" />

          <div className="identity-row">
            <h1>RISHABH PATEL</h1>
            <div className="enrollment">ENROLLMENT NO. - BTCD25O1109</div>
          </div>
        </header>

        <div className="content">
          <aside className="sidebar">
            <section className="side-section contact-section">
              <SectionTitle>CONTACT</SectionTitle>
              <div className="contact-list">
                <div><span className="icon">☎</span><span>+91 9302272851</span></div>
                <div><span className="icon">✉</span><span>rishabhpatel9978@gmail.com</span></div>
                <div><span className="icon">●</span><span>Rajharsh colony , kolar , Bhopal<br />462024</span></div>
              </div>
            </section>

            <section className="side-section hobbies-section">
              <SectionTitle>HOBBIES</SectionTitle>
              <ul className="arrow-list">
                <li>VIDEO EDITING</li>
                <li>PHOTOGRAPHY</li>
                <li>PLAYING CHESS</li>
              </ul>
            </section>

            <section className="side-section tech-section" aria-label="Programming languages">
              <div className="tech-grid">
                <img src={`${A}img2.png`} alt="Python" />
                <img src={`${A}img3.jpeg`} alt="C" />
                <img src={`${A}img4.jpeg`} alt="C++" />
                <img src={`${A}img5.jpeg`} alt="Java" />
              </div>
            </section>

            <section className="side-section languages-section">
              <SectionTitle>LANGUAGES</SectionTitle>
              <ul className="plain-list">
                <li>English: Fluent</li>
                <li>Hindi: Fluent</li>
              </ul>
            </section>
          </aside>

          <section className="main-column">
            <section className="main-section objective-section">
              <SectionTitle>CAREER OBJECTIVE</SectionTitle>
              <ul className="star-list">
                <li>DATA ANALYTIC</li>
                <li>GRAPHIC DESIGNER</li>
                <li>WEB DEVELOPER</li>
              </ul>
            </section>

            <section className="main-section">
              <SectionTitle>SKILLS</SectionTitle>
              <ul className="skills-list">
                <li>Project Management</li>
                <li>Public Relations</li>
                <li>Teamwork</li>
                <li>Time Management</li>
                <li>Effective Communication</li>
                <li>Critical Thinking</li>
              </ul>
            </section>

            <section className="main-section education-section">
              <SectionTitle>EDUCATION</SectionTitle>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>GRADE</th>
                      <th>PASSING YEAR</th>
                      <th>MARKS<br />OBTAINED</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>10th</td>
                      <td>2022</td>
                      <td>454/500</td>
                    </tr>
                    <tr>
                      <td>12th</td>
                      <td>2024</td>
                      <td>397/500</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </section>
          </section>
        </div>
      </article>
    </main>
  );
}

export default App;
