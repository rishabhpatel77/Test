# Rishabh Patel Resume - React

A responsive React/Vite recreation of the uploaded resume.

## Run locally

```bash
npm install
npm run dev
```

Then open the local Vite URL shown in the terminal.

## Production build

```bash
npm run build
npm run preview
```

The images in `public/assets` were extracted from the uploaded resume PDF and reused in the React page.
